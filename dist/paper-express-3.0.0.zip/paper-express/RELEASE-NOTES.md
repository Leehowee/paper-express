# Paper-Express 3.0.0

一个标准 `SKILL.md` 入口，五个按需读取的 `GUIDE.md` 模块，全部模板、代码、合成数据、PPTX/SVG 和第三方许可随包提供。安装与调用见 [INSTALL.md](INSTALL.md)。

项目总览与示例见 [中文 README](README.md) 或 [English README](README_EN.md)。

安装时将仓库链接、发布 ZIP 或解压目录交给 Codex、Claude Code 等智能体，由其使用系统文件工具取得并复制完整技能目录。用户安装无需 Python，包内不提供专用安装脚本。

发布名称为 **Paper-Express**，注册标识与安装目录名为 `paper-express`。历史维护源目录名为 `paper-skills`；历史验证记录保留当时名称，不作为当前调用标识。

发布版由维护源生成：改写子模块入口和交叉引用；将包外原始论文/上游归档的链接改为来源文字；对历史 Lean 构建记录中的本机目录作显式脱敏。原始文件名及引用位置保存在各来源说明中，转换清单见 [distribution-sources.json](references/distribution-sources.json)。不随包分发原文 PDF、上游归档、运行时库或缓存。

代码与模板的科学边界不变。原生 PPTX 构建库是可选的特定环境依赖；现成可编辑模板不依赖该库。历史验证记录与本机安装校验分别记录，不把模板验证当作真实论文验证。

`PACKAGE-MANIFEST.json` 保存所有文件的 SHA-256 和字节数（清单自身除外）；ZIP 旁边提供整包 SHA-256。校验用于内容完整性，不提供身份签名。此包未自动安装到任何全局 agent 目录。
